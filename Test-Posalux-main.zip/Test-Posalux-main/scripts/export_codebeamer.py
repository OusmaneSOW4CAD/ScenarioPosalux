import os
import json
import requests

CODEBEAMER_URL = os.environ["CODEBEAMER_URL"]
USER = os.environ["CODEBEAMER_USER"]
PASSWORD = os.environ["CODEBEAMER_PASSWORD"]

TRACKER_ID = 4497

requirements = []

for item_id in range(1, 10000):

    response = requests.get(
        f"{CODEBEAMER_URL}/cb/rest/item/{item_id}",
        auth=(USER, PASSWORD)
    )

    if response.status_code != 200:
        continue

    item = response.json()

    tracker = item.get("tracker", {})

    if tracker.get("id") != TRACKER_ID:
        continue

    requirements.append({
        "id": item["id"],
        "name": item["name"],
        "description": item.get("description", ""),
        "status": item.get("status", {}).get("name", "")
    })

print(f"{len(requirements)} exigences trouvées")

os.makedirs("requirements", exist_ok=True)

with open(
    "requirements/codebeamer_export.json",
    "w",
    encoding="utf-8"
) as f:
    json.dump(requirements, f, indent=2, ensure_ascii=False)
