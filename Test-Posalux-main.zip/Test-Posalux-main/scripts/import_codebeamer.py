import json
import os
import requests

CODEBEAMER_URL = os.environ["CODEBEAMER_URL"]
TRACKER_ID = os.environ["TRACKER_ID"]

USER = os.environ["CODEBEAMER_USER"]
PASSWORD = os.environ["CODEBEAMER_PASSWORD"]

with open("requirements/codebeamer_requirements.json", encoding="utf-8") as f:
    data = json.load(f)

for req in data["requirements"]:

    payload = {
        "tracker": {
            "id": int(TRACKER_ID)
        },
        "name": req["name"],
        "description": req["description"],
        "status": {
            "name": req["status"]
        }
    }

    r = requests.post(
        f"{CODEBEAMER_URL}/cb/rest/item",
        auth=(USER, PASSWORD),
        json=payload
    )

    print("STATUS =", r.status_code)
    print(r.text)
